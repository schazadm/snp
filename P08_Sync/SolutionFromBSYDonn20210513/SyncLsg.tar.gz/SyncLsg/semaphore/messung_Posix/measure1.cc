//******************************************************************************
// File:    measure1.cc
// Author:  M. Thaler, 15.01.2003
// Purpose: Measures data and puts it in LOWER half of buffer
// Update:  4/2008, Posix IPC
//******************************************************************************

#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>

#include "globalDefs.h"
#include "sem.h"
#include "shm.h"

//******************************************************************************

int main(void) {
    char* displayBuf;
    int   i,j;
    int   shMemObj;

    SharedMemory shm = SharedMemory(SHM_MEMORY, SH_MEM_SZ);
    displayBuf = (char *)(shm.getSharedMemory());

    Semaphor writersTurn1 = Semaphor(WRITERS1_TURN);
    Semaphor readersTurn  = Semaphor(READERS_TURN);
    Semaphor doneAll      = Semaphor(DONE);

    for (j = 0; j <= 9; j++) {          // do it 10 times
        writersTurn1.down();
        for (i = 0 ; i < 5; i++) { 
            displayBuf[i] = j + '0';    // fill displayBuf with ASCII-code of j
            usleep(60000);              // block for 60ms
        }    
        readersTurn.up();
    }      
  
    doneAll.down();                   // synchronize termination
    printf("measure 1 terminates\n");
}

//******************************************************************************

