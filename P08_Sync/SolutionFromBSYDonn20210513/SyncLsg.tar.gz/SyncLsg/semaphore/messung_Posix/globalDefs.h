#ifndef GLOBAL_DEFINITIONS_
#define GLOBAL_DEFINITIONS_

//**********************************************************************
// File:    globalDefs.h
// Author:  M. Thaler    15.01.2003
//          Sept. 2003: counting semaphores
// Purpose: Global definitions for semaphores
//**********************************************************************

// definition of semaphor names (index into sempahore array)

#define NUM_OF_SEMS     4

#define WRITERS1_TURN   "/writers1_turn_sem"
#define WRITERS2_TURN   "/writers2_turn_sem"
#define READERS_TURN    "/readers_turn_sem"
#define DONE            "/done_sem"

// global definitions for shared memory

#define SH_MEM_SZ 32

// global definitions to get a key for the semaphore array

#define SHM_MEMORY "/shared_mem_object"

//**********************************************************************

#endif
