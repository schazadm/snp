//******************************************************************************
// File:    display.cc
// Author:  M. Thaler, 15.01.2003
// Purpose: reads data from shared memeory and displays them
// Update:  4/2008, Posix IPC
//******************************************************************************

#include <unistd.h>
#include <sched.h>
#include <stdio.h>
#include <semaphore.h>
#include <errno.h>
#include <signal.h>

#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>

#include "globalDefs.h"
#include "sem.h"
#include "shm.h"

//******************************************************************************

int main(void) {

    int   doneVal = 3;    
    int   i;
    char  *displayBuf;
    int   shMemObj;

    SharedMemory shm = SharedMemory(SHM_MEMORY, SH_MEM_SZ, 0);
    displayBuf = (char *)(shm.getSharedMemory());

    for (i = 0; i < SH_MEM_SZ; i++)
        displayBuf[i] = ' ';

    Semaphor writersTurn1 = Semaphor(WRITERS1_TURN, 1);
    Semaphor writersTurn2 = Semaphor(WRITERS2_TURN, 1);
    Semaphor readersTurn  = Semaphor(READERS_TURN,  0);
    Semaphor doneAll      = Semaphor(DONE,          3);

    printf("Display starting \n");
    doneVal = doneAll.getVal();
    while (doneVal > 1) {
        readersTurn.down();
        readersTurn.down();

        printf("displayBuf = ");
        for (i = 0 ; i < 11; i++) { 
            putchar(displayBuf[i]);
            sched_yield();
        }
        printf("\n");

        writersTurn1.up();
        writersTurn2.up();
        usleep(200000);
        doneVal = doneAll.getVal();
    } 
    printf("display terminates\n");

    shm.remove();

    writersTurn1.remove();
    writersTurn2.remove();
    readersTurn.remove();
    doneAll.remove();

}

//******************************************************************************

