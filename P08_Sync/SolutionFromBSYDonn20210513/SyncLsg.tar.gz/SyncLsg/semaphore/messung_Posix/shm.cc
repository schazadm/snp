//******************************************************************************
// File:    shm.cc
// Author:  M. Thaler, 4/2008
// Purpose: wrapper for posix shared memory
//******************************************************************************

#include <errno.h>
#include <stdio.h>
#include <string.h>

#include "shm.h"

//******************************************************************************

SharedMemory::SharedMemory(char *name, int size, int create) {
    if (strlen(name) > STRLEN) {
        printf("semaphore name to long\n");
        name = NULL;
    }
    strcpy(shmName, name);
    shmSize = size;
    shMemObj = shm_open(name, O_CREAT | O_RDWR, 0774);
    if (shMemObj < 0) {
        printf("%s : ", name);
        perror("could not create shared memory\n");
        exit(-1);
    }
    if (ftruncate(shMemObj, size) < 0) {
        printf("%s : ", name);
        perror("could not setup shared memory\n");
        shm_unlink(name);
        exit(-1);
    }
    shmem = mmap(0, size, PROT_READ | PROT_WRITE,  MAP_SHARED, shMemObj, 0);
    if (shmem == MAP_FAILED) {
        printf("%s : ", name);
        perror("could not attach shared memory\n");
        shm_unlink(name);
        exit(-1);
    }
}

SharedMemory::SharedMemory(char *name, int size) {
    if (strlen(name) > STRLEN) {
        printf("semaphore name to long\n");
        name = NULL;
    }
    strcpy(shmName, name);
    shmSize = size;
    shMemObj = shm_open(name, O_RDWR, 0774);
    if (shMemObj < 0) {
        printf("%s : ", name);
        perror("could not create shared memory\n");
        exit(-1);
    }
    shmem = mmap(0, size, PROT_READ | PROT_WRITE,  MAP_SHARED, shMemObj, 0);
    if (shmem == MAP_FAILED) {
        printf("%s : ", name);
        perror("could not attach shared memory\n");
        shm_unlink(name);
        exit(-1);
    }
}

SharedMemory::~SharedMemory(){}


void *SharedMemory::getSharedMemory(void) {
    return shmem;
}

void SharedMemory::remove(void) {
    if (shm_unlink(shmName) < 0) {
        printf("%s : ", shmName);
        perror("could not unlink shared memory\n");
    }
}

//******************************************************************************

