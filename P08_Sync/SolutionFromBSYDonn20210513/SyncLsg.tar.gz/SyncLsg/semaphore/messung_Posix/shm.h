//******************************************************************************
// File:    shm.h
// Author:  M. Thaler, 4/2008
// Purpose: wrapper for posix shared memory
//******************************************************************************

#ifndef POSIX_SHAREDMEM_WRAPPER
#define POSIX_SHAREDMEM_WRAPPER

#include <sys/types.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>

//******************************************************************************

#define STRLEN 32

//******************************************************************************
class SharedMemory {

private:
    char shmName[32];
    void *shmem;
    int  shMemObj;
    int  shmSize;

public:
    SharedMemory(char *name, int size, int create);
    SharedMemory(char *name, int size);
    ~SharedMemory(void);
    void *getSharedMemory();   
    void remove(void);

};

#endif
