//******************************************************************************
// File:    sem.h
// Author:  M. Thaler, 4/2008
// Purpose: wrapper for posix semaphores
//******************************************************************************

#ifndef POSIX_SEMAPHORE_WRAPPER
#define POSIX_SEMAPHORE_WRAPPER

#include <semaphore.h>
#include <stdlib.h>
#include <fcntl.h>

//******************************************************************************

#define STRLEN 32

//******************************************************************************
class Semaphor {

private:
    char  semName[STRLEN];
    sem_t *semaphor;

public:
    Semaphor(char *name, int value);
    Semaphor(char *name);
    ~Semaphor(void);

    void down(void);
    void up(void);
    int  getVal(void);
    void remove(void);
};

#endif

//******************************************************************************
