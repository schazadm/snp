//******************************************************************************
// File:    sem.cc
// Author:  M. Thaler, 4/2008
// Purpose: wrapper for posix semaphores
//******************************************************************************

#include <errno.h>
#include <stdio.h>
#include <string.h>

#include "sem.h"

//******************************************************************************

Semaphor::Semaphor(char *name, int value) {
    if (strlen(name) > STRLEN) {
        printf("semaphore name to long\n");
        name = NULL;
    }
    strcpy(semName, name);
    semaphor = sem_open(semName, O_CREAT, 0774, value);
    if (semaphor == SEM_FAILED) {
        printf("%s: ", name);
        perror("cannot create semaphor\n"); 
        exit(-1);
    }
}

Semaphor::Semaphor(char *name) {
    if (strlen(name) > STRLEN) {
        printf("semaphore name to long\n");
        name = NULL;
    }
    semaphor = sem_open(name, 0);
    if (semaphor == SEM_FAILED) {
        printf("%s: ", name);
        perror("cannot get semaphor\n"); 
        exit(-1);
    }
}

Semaphor::~Semaphor() {}

void Semaphor::down(void) {
    if (sem_wait(semaphor) < 0) {
        perror("semaphore down failed\n");
    }
}

void Semaphor::up(void) {
    if (sem_post(semaphor) < 0) {
        perror("semaphore down failed\n");
    }
}

int Semaphor::getVal(void) {
    int retval;
    if (sem_getvalue(semaphor, &retval) < 0) {
        perror("semaphor not available\n");
    }
    return retval;
}

void Semaphor::remove(void) {
    if (sem_unlink(semName) < 0) {
        printf("%s: ", semName);
        perror("cannot unlink semaphor\n");
    }
}

//******************************************************************************

