//******************************************************************************
// File:        display.cc
// Author:	M. Thaler    15.01.2003
// 
// Display process: reads data from shared memeory and displays them
//******************************************************************************

#include <unistd.h>
#include <sched.h>
#include <stdio.h>
#include "shmem.h"
#include "semaphore.h"
#include "globalDefs.h"

#include <stdio.h>
#include <iostream>
using namespace std;

//******************************************************************************

int main(void) {
	
	int   i;
	char* displayBuf;
	
	SharedMemory shm = 
		SharedMemory(SH_MEM_SZ, SHM_KEY_FILE_NAME, PROJ_ID);
	displayBuf = (char *)(shm.getSharedMemory());
	for (i = 0; i < SH_MEM_SZ; i++)
		displayBuf[i] = ' ';
	
	Semaphore sem = 
		Semaphore(NUM_OF_SEMS, SEM_KEY_FILE_NAME, PROJ_ID);
	sem.setValue(WRITERS1_TURN, 1);
	sem.setValue(WRITERS2_TURN, 1);
	sem.setValue(READERS_TURN, 0);
	sem.setValue(DONE, 3);

	cout << endl;
	while (sem.getValue(DONE) > 1) {
		sem.down(READERS_TURN);
		sem.down(READERS_TURN);
		cout << "displayBuf = ";
		for (i = 0 ; i < 11; i++) { 
			putchar(displayBuf[i]);
			sched_yield();
		}
		cout << endl;
		sem.up(WRITERS1_TURN);
		sem.up(WRITERS2_TURN);
		usleep(200000);
	} 
	cout << "display terminates\n";
	shm.removeSharedMemory();
	sem.removeSemaphore();
}

//******************************************************************************

