#ifndef GLOBAL_DEFINITIONS_
#define GLOBAL_DEFINITIONS_

//**********************************************************************
// File:        globalDefs.h
// Author:	M. Thaler    15.01.2003
//		Sept. 2003: counting semaphores
// 
// Global definitions for semaphores
//**********************************************************************

// definition of semaphor names (index into sempahore array)

#define	NUM_OF_SEMS	4

#define WRITERS1_TURN	0
#define WRITERS2_TURN	1
#define READERS_TURN	2
#define DONE		3

// global definitions for shared memory

#define SH_MEM_SZ 32

// global definitions to get a key for the semaphore array

#define PROJ_ID	233
#define SEM_KEY_FILE_NAME "/tmp/key_file.sem"
#define SHM_KEY_FILE_NAME "/tmp/key_file.shm"

//**********************************************************************

#endif
