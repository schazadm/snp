//******************************************************************************
// File:        measure1.cc
// Author:	M. Thaler    15.01.2003
// 
// Measures data and puts it in lower half of buffer
//******************************************************************************

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include "shmem.h"
#include "semaphore.h"
#include "globalDefs.h"

#include <stdio.h>
#include <iostream>
using namespace std;

//******************************************************************************

int main(void) {
	char* displayBuf;
	int   i,j;

	SharedMemory shm = 
		SharedMemory(0, SHM_KEY_FILE_NAME, PROJ_ID);
	displayBuf = (char *)(shm.getSharedMemory());

	Semaphore sem = Semaphore(0, SEM_KEY_FILE_NAME, PROJ_ID);

        for (j = 0; j <= 9; j++) { 		// do it 10 times
		sem.down(WRITERS1_TURN);
		// displayBuf is filled with the ASCII-code of the number j
		// after each access, the process is blocked for 60ms
		for (i = 0 ; i < 5; i++) { 
			displayBuf[i] = j + '0'; 
			usleep(60000); 
		}    
		sem.up(READERS_TURN);
	}        
	sem.down(DONE);				// synchronize termination
	cout << "measure 1 terminates" << endl;
}

//******************************************************************************

