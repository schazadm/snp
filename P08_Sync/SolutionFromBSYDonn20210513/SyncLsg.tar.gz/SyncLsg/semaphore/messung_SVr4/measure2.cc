//******************************************************************************
// File:        measure2.cc
// Author:	M. Thaler    15.01.2003
// 
// Measures data and puts it in upper half of buffer
//******************************************************************************

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include "shmem.h"
#include "semaphore.h"
#include "globalDefs.h"

#include <iostream>
using namespace std;

//******************************************************************************

int main(void) {
	char* displayBuf;
	int   i,j;

        SharedMemory shm = 
                SharedMemory(0, SHM_KEY_FILE_NAME, PROJ_ID);
	displayBuf = (char *)(shm.getSharedMemory());

	Semaphore sem = Semaphore(0, SEM_KEY_FILE_NAME, PROJ_ID);

        for (j = 0; j <= 9; j++) { 		// do it 10 times
		sem.down(WRITERS2_TURN);
		// displayBuf is filled with the ASCII-code of the number j
		// after each access, the process is blocked for 80ms
		for (i = 0 ; i < 5; i++) { 
			displayBuf[i + 6] = j + '0'; 
			usleep(80000); 
		}    
		sem.up(READERS_TURN);
	}      
	sem.down(DONE);				// synchronize termnation
	cout << "measure 2 terminates" << endl;
}

//******************************************************************************

