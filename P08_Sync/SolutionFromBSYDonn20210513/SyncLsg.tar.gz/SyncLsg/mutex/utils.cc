//******************************************************************************
// Author	Fach BS, ZHW,  M. Thaler
// Purpose	Utilities for "Suedanflug"
// File		utils.cc
//******************************************************************************

#include <stdio.h>
#include <sched.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/times.h>

#include "utils.h"

//******************************************************************************
// Wait for touch down (sleep randomly for 50ms .. 750ms)
//------------------------------------------------------------------------------

void WaitForTouchDown(unsigned long *Clock) {
    static unsigned long lastTouchDown = 0;
    unsigned long time, myTouchDown;
    double ranVal;

    ranVal = ((double)random()) / RAND_MAX;
    ranVal = 10 + 150 * ranVal;
    time = (unsigned long)ranVal;
    if (time < CRASH_DELAY)
	time = CRASH_DELAY;
    myTouchDown = *Clock + time;
    usleep(time * 5000);
    if ((myTouchDown - lastTouchDown) < CRASH_DELAY)
	printf("*CRASH*");
    lastTouchDown = *Clock = myTouchDown;
	//printf (" %d ---\n", *Clock);
}

//******************************************************************************
// Wait for next arrival (sleep randomly for 50ms .. 750ms)
//------------------------------------------------------------------------------

void WaitForNextFlightArrival(void) {
    double ranVal;
    unsigned long time;
    ranVal = ((double)random()) / RAND_MAX;
    ranVal = 10 + 150 * ranVal;
    time = (unsigned long)ranVal;
    usleep(time * 5000);
}

//******************************************************************************
// Announce landing
//------------------------------------------------------------------------------

void AnnounceLanding(void *Data) {
    ControllerData *data  = (ControllerData *)Data;
    printf("%s: %s\n", data->Name, data->FlightList[data->FlightNum]);
    data->FlightNum++;
}

//******************************************************************************
// Give landing permission
//------------------------------------------------------------------------------

void GiveLandingClearance(void *Data) {
    if (Data != 0) {
    	ControllerData data  = *(ControllerData *)Data;
	printf("%s: ok\n", data.Name);
	fflush(stdout);
    }
}

//******************************************************************************
// read the system time and seed the random genrator used by rt()
//	=> never twice the same result
//------------------------------------------------------------------------------

void randomize(void) {
    unsigned int time;
    struct tms sys_times;
    time  = (unsigned int) times(&sys_times);
    srandom(time);
}

//******************************************************************************
