#ifndef FLIGHTS_INCLUDE
#define FLIGHTS_INCLUDE

#define FLIGHTS 20

char *southFlights[FLIGHTS] = {
			"LX  425",
			"LH  236",
			"LX  937",
			"LX  444",
			"AF  545",

			"JL  465",
			"LX  138",
			"CP  553",
			"LX  354",
 			"LX  556",
 
			"BA  601",
			"LX  608",
			"LH  609",
			"LH  611",
			"LX  633",

			"LX  704",
			"LH  777",
			"AA  778",
			"LX  791",
			"SAS 792"
		    };

char *eastFlights[FLIGHTS] = {
			"LH  425",
			"SAS 436",
			"BA  007",
			"LX  444",
			"AA  445",
 
 			"AA  465",
			"LH  738",
			"JL  799",
			"LX  554",
			"LX  256",

			"AA  601",
			"LX  808",
			"SAS 609",
			"LH  111",
			"CP  033",

			"LH  304",
			"LX  407",
			"LX  178",
			"LX  351",
			"LX  222"
		    };

char *northFlights[FLIGHTS] = {
			"AA  965",
			"LH  938",
			"JL  999",
			"LX  994",
			"SAS 956",

 			"JL  925",
			"SAS 936",
			"BA  907",
			"LX  944",
			"AA  945",

			"LH  904",
			"LX  907",
			"LX  978",
			"LX  951",
			"LX  922",

			"AA  901",
			"LX  908",
			"SAS 909",
			"LH  911",
			"CP  933"
		    };
#endif
