#ifndef SUED_UTILS_H
#define SUED_UTILS_H

//******************************************************************************
// Author       Fach BS, ZHW,  M. Thaler
// Purpose      Utilities for "Suedanflug"
// File		utils.h
//******************************************************************************

#include <stdio.h>
#include <sched.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/times.h>

//******************************************************************************

#define CRASH_DELAY 20

//******************************************************************************

typedef enum {north = 0, east = 1, south = 2} LandingDirection;

typedef struct {
	char 		 *Name;
	char 		 **FlightList;
	int		 FlightNum;
	LandingDirection ownDirection;
} ControllerData;

//******************************************************************************
// Wait for touch down 
//------------------------------------------------------------------------------

void WaitForTouchDown(unsigned long *Clock);

//******************************************************************************
// Wait for next arrival
//------------------------------------------------------------------------------

void WaitForNextFlightArrival(void);

//******************************************************************************
// Announce landing
//------------------------------------------------------------------------------

void AnnounceLanding(void *Data);

//******************************************************************************
// Give landing permission
//------------------------------------------------------------------------------

void GiveLandingClearance(void *Data);

//******************************************************************************
// read the system time and seed the random genrator used by rt()
//	=> never twice the same result
//------------------------------------------------------------------------------

void randomize(void);

//******************************************************************************

#endif
