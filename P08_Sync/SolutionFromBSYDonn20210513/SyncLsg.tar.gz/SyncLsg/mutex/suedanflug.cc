//******************************************************************************
// Author       Fach BS, ZHW,  J. Zeman, Sept. 99
// Purpose      Mutex mit Pthreads
// Modification M. Thaler, modified Mar. 2000
//              - changed to c++ compatabiltity (ANSI)
//              - changed functions to void *fun(void *)
//              - added "culture"
//              M. Thaler, modified Oct. 2003
//              - changed to Sueanflug
//******************************************************************************

#include <stdio.h>
#include <sched.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/times.h>

//******************************************************************************

#include "flights.h"
#include "utils.h"

//******************************************************************************

#define TestData 0
//#define TestData Data

void *FlightControllerSouth(void *);
void *FlightControllerEast(void *);
void *FlightControllerNorth(void *);

pthread_mutex_t UniqueAirPort;

unsigned long Clock = 100;

LandingDirection direction = north;

//******************************************************************************

int main (void)
{
    randomize();			// randomize the random generator

    pthread_t thread1, thread2, thread3;

    ControllerData South;
    South.Name		= "\tSuedanflug";
    South.FlightList	= southFlights;
    South.ownDirection	= south;
    South.FlightNum	 = 0;

    ControllerData East;
    East.Name		= "\t\t\t\tOstanflug";
    East.FlightList	= eastFlights;
    East.ownDirection	= east;
    East.FlightNum	= 0;

    ControllerData North;
    North.Name		= "\t\t\t\t\t\t\tNordanflug";
    North.FlightList	= northFlights;
    North.ownDirection	= north;
    North.FlightNum	= 0;

    pthread_mutex_init(&UniqueAirPort, NULL);
    pthread_mutex_unlock(&UniqueAirPort);

    printf("\nSimulation started\n\n");

    pthread_create(&thread1, NULL, FlightControllerSouth, &South);
    pthread_create(&thread2, NULL, FlightControllerEast,  &East);
    pthread_create(&thread3, NULL, FlightControllerNorth, &North);

    pthread_join (thread1, NULL);  // auf Terminierung des Threads warten
    pthread_join (thread2, NULL);  // dito
    pthread_join (thread3, NULL);  // dito

    exit(0); 
}

//******************************************************************************
// The Thread Funktion that simulates the behavior of the FlightControllers
//------------------------------------------------------------------------------

void *FlightControllerSouth(void *Data)		// Thread - Funktion
{
    ControllerData *data = (ControllerData *)Data;

    while (data->FlightNum < FLIGHTS) {
	WaitForNextFlightArrival();
	pthread_mutex_lock(&UniqueAirPort);
	if (data->ownDirection == direction) {
	    GiveLandingClearance(TestData);
	    WaitForTouchDown(&Clock);
	    AnnounceLanding(Data);
	    direction = north;
	}
	pthread_mutex_unlock(&UniqueAirPort);
    }
    pthread_exit(0);   
}

//------------------------------------------------------------------------------

void *FlightControllerEast(void *Data)		// Thread - Funktion
{
    ControllerData *data = (ControllerData *)Data;

    while (data->FlightNum < FLIGHTS) {
	WaitForNextFlightArrival();
	pthread_mutex_lock(&UniqueAirPort);
	if (data->ownDirection == direction) {
	    GiveLandingClearance(TestData);
	    WaitForTouchDown(&Clock);
	    AnnounceLanding(Data);
	    direction = south;
	}
	pthread_mutex_unlock(&UniqueAirPort);
    }
    pthread_exit(0);   
}

//------------------------------------------------------------------------------

void *FlightControllerNorth(void *Data)		// Thread - Funktion
{
    ControllerData *data = (ControllerData *)Data;

    while (data->FlightNum < FLIGHTS) {
	WaitForNextFlightArrival();
	pthread_mutex_lock(&UniqueAirPort);
	if (data->ownDirection == direction) {
	    GiveLandingClearance(TestData);
	    WaitForTouchDown(&Clock);
	    AnnounceLanding(Data);
	    direction = east;
	}
	pthread_mutex_unlock(&UniqueAirPort);
    }
    pthread_exit(0);   
}

//******************************************************************************
